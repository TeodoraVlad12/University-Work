﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB
{
    //Data Source=127.0.0.1;Initial Catalog=DB2;User ID=teo-vs;Password=violet
    public partial class Form1 : Form
    {
        SqlConnection connection = new SqlConnection("Data Source=127.0.0.1;Initial Catalog=DB2;User ID=teo-vs;Password=violet");
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
// TODO: This line of code loads data into the 'dB2DataSet2.Donation' table. You can move, or remove it, as needed.
this.donationTableAdapter.Fill(this.dB2DataSet2.Donation);
            // TODO: This line of code loads data into the 'dB2DataSet2.Person' table. You can move, or remove it, as needed.
            //this.personTableAdapter.Fill(this.dB2DataSet2.Person);
            // TODO: This line of code loads data into the 'dB2DataSet2.Employee' table. You can move, or remove it, as needed.
            //this.employeeTableAdapter.Fill(this.dB2DataSet2.Employee);
            // TODO: This line of code loads data into the 'dB2DataSet2.Animal' table. You can move, or remove it, as needed.
            // this.animalTableAdapter.Fill(this.dB2DataSet2.Animal);

            SqlDataAdapter dataAdapter = new SqlDataAdapter("select * from Person", connection);
            DataSet dataset = new DataSet();
            dataAdapter.Fill(dataset, "Person");
            dataGridViewPerson.DataSource = dataset.Tables["Person"];

            
         



        }

        

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var id = dataGridViewPerson.Rows[e.RowIndex].Cells[0].Value;
            string sqlCommand = "select * from Donation where PersonId=@personId";

            SqlCommand getEmployeesById = new SqlCommand(sqlCommand, connection);
            getEmployeesById.Parameters.AddWithValue("@personId", id);
            DataSet ds = new DataSet();
            SqlDataAdapter datAd = new SqlDataAdapter(getEmployeesById);
            datAd.Fill(ds,"Donation");
            dataGridView1.DataSource = ds.Tables["Donation"];



        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        //dataGridView1 - child
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            


        }

        

        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Make sure a valid row is clicked
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];



                // Assuming the columns in your dataGridView1 correspond to the columns in your database table
                textBoxPersonID.Text = selectedRow.Cells[0].Value.ToString();

                textBoxDonationType.Text = selectedRow.Cells[1].Value.ToString();
                textBoxDonationAmount.Text = selectedRow.Cells[2].Value.ToString();
                textBoxDate.Text = selectedRow.Cells[3].Value.ToString();


            }

        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (textBoxPersonID.Text != "" && textBoxDonationType.Text != "" && textBoxDonationAmount.Text != "" && textBoxDate.Text != "")
            {
                try
                {
                    // Create the SQL INSERT command with parameters to prevent SQL injection
                    string insertCommand = "INSERT INTO Donation (PersonId, DonationType, DonationAmount, DonationDate) VALUES (@PersonId, @DonationType, @DonationAmount, @DonationDate)";
                    SqlCommand insertCmd = new SqlCommand(insertCommand, connection);

                    // Add parameter values
                    insertCmd.Parameters.AddWithValue("@PersonId", textBoxPersonID.Text);
                    insertCmd.Parameters.AddWithValue("@DonationType", textBoxDonationType.Text);
                    insertCmd.Parameters.AddWithValue("@DonationAmount", textBoxDonationAmount.Text);
                    insertCmd.Parameters.AddWithValue("@DonationDate", textBoxDate.Text);

                    // Open the connection
                    connection.Open();

                    // Execute the command
                    insertCmd.ExecuteNonQuery();

                    // Display a success message
                    MessageBox.Show("Data inserted successfully.");

                    SqlDataAdapter dataAdapter = new SqlDataAdapter("select * from Donation", connection);
                    DataSet dataset = new DataSet();
                    dataAdapter.Fill(dataset, "Donation");
                    dataGridView1.DataSource = dataset.Tables["Donation"];

                    // Optionally, clear the text boxes after insertion
                    textBoxPersonID.Text = "";
                    textBoxDonationType.Text = "";
                    textBoxDonationAmount.Text = "";
                    textBoxDate.Text = "";
                }
                catch (Exception ex)
                {
                    // Display an error message if something goes wrong
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    // Close the connection
                    connection.Close();
                }
            }
            else
            {
                MessageBox.Show("Please fill all fields before adding.");
            }
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            // Check if all necessary text boxes are filled
            if (textBoxPersonID.Text != "" && textBoxDonationType.Text != "" && textBoxDate.Text != "" && textBoxDonationAmount.Text != "")
            {
                try
                {
                    // Create the SQL UPDATE command
                    string updateCommand = "UPDATE Donation SET DonationAmount = @DonationAmount WHERE PersonId = @PersonId AND DonationType = @DonationType AND DonationDate = @DonationDate";
                    SqlCommand updateCmd = new SqlCommand(updateCommand, connection);

                    // Add parameter values
                    updateCmd.Parameters.AddWithValue("@DonationAmount", textBoxDonationAmount.Text);
                    updateCmd.Parameters.AddWithValue("@PersonId", textBoxPersonID.Text);
                    updateCmd.Parameters.AddWithValue("@DonationType", textBoxDonationType.Text);
                    updateCmd.Parameters.AddWithValue("@DonationDate", textBoxDate.Text);

                    // Open the connection
                    connection.Open();

                    // Execute the command
                    int rowsAffected = updateCmd.ExecuteNonQuery();

                    // Check if the update was successful
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Data updated successfully.");

                        
                        SqlDataAdapter dataAdapter = new SqlDataAdapter("select * from Donation", connection);
                        DataSet dataset = new DataSet();
                        dataAdapter.Fill(dataset, "Donation");
                        dataGridView1.DataSource = dataset.Tables["Donation"];
                    }
                    else
                    {
                        MessageBox.Show("No rows were updated. Please check if the specified donation exists.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    // Close the connection
                    connection.Close();
                }
            }
            else
            {
                MessageBox.Show("Please fill all fields before updating.");
            }

        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            // Check if all necessary text boxes are filled
            if (textBoxPersonID.Text != "" && textBoxDonationType.Text != "" && textBoxDate.Text != "" && textBoxDonationAmount.Text != "")
            {
                try
                {
                    // Create the SQL UPDATE command
                    string deleteCommand = "DELETE FROM Donation WHERE DonationAmount = @DonationAmount AND PersonId = @PersonId AND DonationType = @DonationType AND DonationDate = @DonationDate";
                    SqlCommand deleteCmd = new SqlCommand(deleteCommand, connection);

                    // Add parameter values
                    deleteCmd.Parameters.AddWithValue("@DonationAmount", textBoxDonationAmount.Text);
                    deleteCmd.Parameters.AddWithValue("@PersonId", textBoxPersonID.Text);
                    deleteCmd.Parameters.AddWithValue("@DonationType", textBoxDonationType.Text);
                    deleteCmd.Parameters.AddWithValue("@DonationDate", textBoxDate.Text);

                    // Open the connection
                    connection.Open();

                    // Execute the command
                    int rowsAffected = deleteCmd.ExecuteNonQuery();

                    // Check if the update was successful
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Data deleted successfully.");


                        SqlDataAdapter dataAdapter = new SqlDataAdapter("select * from Donation", connection);
                        DataSet dataset = new DataSet();
                        dataAdapter.Fill(dataset, "Donation");
                        dataGridView1.DataSource = dataset.Tables["Donation"];
                    }
                    else
                    {
                        MessageBox.Show("No rows were deleted. Please check if the specified donation exists.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    // Close the connection
                    connection.Close();
                }
            }
            else
            {
                MessageBox.Show("Please fill all fields before deleting.");
            }



        }
    }
}

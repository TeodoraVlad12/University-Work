﻿namespace DB
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dB2DataSet2 = new DB.DB2DataSet2();
            this.animalBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.animalTableAdapter = new DB.DB2DataSet2TableAdapters.AnimalTableAdapter();
            this.dB2DataSet3 = new DB.DB2DataSet3();
            this.dB2DataSet3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.animalBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewPerson = new System.Windows.Forms.DataGridView();
            this.personIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.personFirstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.personLastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.personAgeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.personCountryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.personPhoneNrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.personEmailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.personBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.employeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.employeeTableAdapter = new DB.DB2DataSet2TableAdapters.EmployeeTableAdapter();
            this.personTableAdapter = new DB.DB2DataSet2TableAdapters.PersonTableAdapter();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeSpecializationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeSalaryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.donationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.donationTableAdapter = new DB.DB2DataSet2TableAdapters.DonationTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.personIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.donationTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.donationAmountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.donationDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.donationBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.textBoxDonationType = new System.Windows.Forms.TextBox();
            this.textBoxDonationAmount = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxDate = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.textBoxPersonID = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dB2DataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.animalBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB2DataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB2DataSet3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.animalBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPerson)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.donationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.donationBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // dB2DataSet2
            // 
            this.dB2DataSet2.DataSetName = "DB2DataSet2";
            this.dB2DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // animalBindingSource
            // 
            this.animalBindingSource.DataMember = "Animal";
            this.animalBindingSource.DataSource = this.dB2DataSet2;
            // 
            // animalTableAdapter
            // 
            this.animalTableAdapter.ClearBeforeFill = true;
            // 
            // dB2DataSet3
            // 
            this.dB2DataSet3.DataSetName = "DB2DataSet3";
            this.dB2DataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dB2DataSet3BindingSource
            // 
            this.dB2DataSet3BindingSource.DataSource = this.dB2DataSet3;
            this.dB2DataSet3BindingSource.Position = 0;
            // 
            // animalBindingSource1
            // 
            this.animalBindingSource1.DataMember = "Animal";
            this.animalBindingSource1.DataSource = this.dB2DataSet2;
            // 
            // dataGridViewPerson
            // 
            this.dataGridViewPerson.AutoGenerateColumns = false;
            this.dataGridViewPerson.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPerson.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.personIDDataGridViewTextBoxColumn,
            this.personFirstNameDataGridViewTextBoxColumn,
            this.personLastNameDataGridViewTextBoxColumn,
            this.personAgeDataGridViewTextBoxColumn,
            this.personCountryDataGridViewTextBoxColumn,
            this.personPhoneNrDataGridViewTextBoxColumn,
            this.personEmailDataGridViewTextBoxColumn});
            this.dataGridViewPerson.DataSource = this.personBindingSource;
            this.dataGridViewPerson.Location = new System.Drawing.Point(475, 27);
            this.dataGridViewPerson.Name = "dataGridViewPerson";
            this.dataGridViewPerson.RowHeadersWidth = 51;
            this.dataGridViewPerson.RowTemplate.Height = 24;
            this.dataGridViewPerson.Size = new System.Drawing.Size(240, 150);
            this.dataGridViewPerson.TabIndex = 1;
            this.dataGridViewPerson.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // personIDDataGridViewTextBoxColumn
            // 
            this.personIDDataGridViewTextBoxColumn.DataPropertyName = "PersonID";
            this.personIDDataGridViewTextBoxColumn.HeaderText = "PersonID";
            this.personIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.personIDDataGridViewTextBoxColumn.Name = "personIDDataGridViewTextBoxColumn";
            this.personIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // personFirstNameDataGridViewTextBoxColumn
            // 
            this.personFirstNameDataGridViewTextBoxColumn.DataPropertyName = "PersonFirstName";
            this.personFirstNameDataGridViewTextBoxColumn.HeaderText = "PersonFirstName";
            this.personFirstNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.personFirstNameDataGridViewTextBoxColumn.Name = "personFirstNameDataGridViewTextBoxColumn";
            this.personFirstNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // personLastNameDataGridViewTextBoxColumn
            // 
            this.personLastNameDataGridViewTextBoxColumn.DataPropertyName = "PersonLastName";
            this.personLastNameDataGridViewTextBoxColumn.HeaderText = "PersonLastName";
            this.personLastNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.personLastNameDataGridViewTextBoxColumn.Name = "personLastNameDataGridViewTextBoxColumn";
            this.personLastNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // personAgeDataGridViewTextBoxColumn
            // 
            this.personAgeDataGridViewTextBoxColumn.DataPropertyName = "PersonAge";
            this.personAgeDataGridViewTextBoxColumn.HeaderText = "PersonAge";
            this.personAgeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.personAgeDataGridViewTextBoxColumn.Name = "personAgeDataGridViewTextBoxColumn";
            this.personAgeDataGridViewTextBoxColumn.Width = 125;
            // 
            // personCountryDataGridViewTextBoxColumn
            // 
            this.personCountryDataGridViewTextBoxColumn.DataPropertyName = "PersonCountry";
            this.personCountryDataGridViewTextBoxColumn.HeaderText = "PersonCountry";
            this.personCountryDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.personCountryDataGridViewTextBoxColumn.Name = "personCountryDataGridViewTextBoxColumn";
            this.personCountryDataGridViewTextBoxColumn.Width = 125;
            // 
            // personPhoneNrDataGridViewTextBoxColumn
            // 
            this.personPhoneNrDataGridViewTextBoxColumn.DataPropertyName = "PersonPhoneNr";
            this.personPhoneNrDataGridViewTextBoxColumn.HeaderText = "PersonPhoneNr";
            this.personPhoneNrDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.personPhoneNrDataGridViewTextBoxColumn.Name = "personPhoneNrDataGridViewTextBoxColumn";
            this.personPhoneNrDataGridViewTextBoxColumn.Width = 125;
            // 
            // personEmailDataGridViewTextBoxColumn
            // 
            this.personEmailDataGridViewTextBoxColumn.DataPropertyName = "PersonEmail";
            this.personEmailDataGridViewTextBoxColumn.HeaderText = "PersonEmail";
            this.personEmailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.personEmailDataGridViewTextBoxColumn.Name = "personEmailDataGridViewTextBoxColumn";
            this.personEmailDataGridViewTextBoxColumn.Width = 125;
            // 
            // personBindingSource
            // 
            this.personBindingSource.DataMember = "Person";
            this.personBindingSource.DataSource = this.dB2DataSet2;
            // 
            // employeeBindingSource
            // 
            this.employeeBindingSource.DataMember = "Employee";
            this.employeeBindingSource.DataSource = this.dB2DataSet2;
            // 
            // employeeTableAdapter
            // 
            this.employeeTableAdapter.ClearBeforeFill = true;
            // 
            // personTableAdapter
            // 
            this.personTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.employeeIDDataGridViewTextBoxColumn,
            this.employeeSpecializationDataGridViewTextBoxColumn,
            this.employeeSalaryDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.employeeBindingSource1;
            this.dataGridView3.Location = new System.Drawing.Point(50, 27);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(240, 150);
            this.dataGridView3.TabIndex = 2;
            // 
            // employeeIDDataGridViewTextBoxColumn
            // 
            this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.HeaderText = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
            this.employeeIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // employeeSpecializationDataGridViewTextBoxColumn
            // 
            this.employeeSpecializationDataGridViewTextBoxColumn.DataPropertyName = "EmployeeSpecialization";
            this.employeeSpecializationDataGridViewTextBoxColumn.HeaderText = "EmployeeSpecialization";
            this.employeeSpecializationDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeeSpecializationDataGridViewTextBoxColumn.Name = "employeeSpecializationDataGridViewTextBoxColumn";
            this.employeeSpecializationDataGridViewTextBoxColumn.Width = 125;
            // 
            // employeeSalaryDataGridViewTextBoxColumn
            // 
            this.employeeSalaryDataGridViewTextBoxColumn.DataPropertyName = "EmployeeSalary";
            this.employeeSalaryDataGridViewTextBoxColumn.HeaderText = "EmployeeSalary";
            this.employeeSalaryDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeeSalaryDataGridViewTextBoxColumn.Name = "employeeSalaryDataGridViewTextBoxColumn";
            this.employeeSalaryDataGridViewTextBoxColumn.Width = 125;
            // 
            // employeeBindingSource1
            // 
            this.employeeBindingSource1.DataMember = "Employee";
            this.employeeBindingSource1.DataSource = this.dB2DataSet2;
            // 
            // donationBindingSource
            // 
            this.donationBindingSource.DataMember = "Donation";
            this.donationBindingSource.DataSource = this.dB2DataSet2;
            // 
            // donationTableAdapter
            // 
            this.donationTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.personIDDataGridViewTextBoxColumn1,
            this.donationTypeDataGridViewTextBoxColumn,
            this.donationAmountDataGridViewTextBoxColumn,
            this.donationDateDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.donationBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(38, 213);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(288, 150);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick_1);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // personIDDataGridViewTextBoxColumn1
            // 
            this.personIDDataGridViewTextBoxColumn1.DataPropertyName = "PersonID";
            this.personIDDataGridViewTextBoxColumn1.HeaderText = "PersonID";
            this.personIDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.personIDDataGridViewTextBoxColumn1.Name = "personIDDataGridViewTextBoxColumn1";
            this.personIDDataGridViewTextBoxColumn1.Width = 125;
            // 
            // donationTypeDataGridViewTextBoxColumn
            // 
            this.donationTypeDataGridViewTextBoxColumn.DataPropertyName = "DonationType";
            this.donationTypeDataGridViewTextBoxColumn.HeaderText = "DonationType";
            this.donationTypeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.donationTypeDataGridViewTextBoxColumn.Name = "donationTypeDataGridViewTextBoxColumn";
            this.donationTypeDataGridViewTextBoxColumn.Width = 125;
            // 
            // donationAmountDataGridViewTextBoxColumn
            // 
            this.donationAmountDataGridViewTextBoxColumn.DataPropertyName = "DonationAmount";
            this.donationAmountDataGridViewTextBoxColumn.HeaderText = "DonationAmount";
            this.donationAmountDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.donationAmountDataGridViewTextBoxColumn.Name = "donationAmountDataGridViewTextBoxColumn";
            this.donationAmountDataGridViewTextBoxColumn.Width = 125;
            // 
            // donationDateDataGridViewTextBoxColumn
            // 
            this.donationDateDataGridViewTextBoxColumn.DataPropertyName = "DonationDate";
            this.donationDateDataGridViewTextBoxColumn.HeaderText = "DonationDate";
            this.donationDateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.donationDateDataGridViewTextBoxColumn.Name = "donationDateDataGridViewTextBoxColumn";
            this.donationDateDataGridViewTextBoxColumn.Width = 125;
            // 
            // donationBindingSource1
            // 
            this.donationBindingSource1.DataMember = "Donation";
            this.donationBindingSource1.DataSource = this.dB2DataSet2;
            // 
            // textBoxDonationType
            // 
            this.textBoxDonationType.Location = new System.Drawing.Point(426, 232);
            this.textBoxDonationType.Name = "textBoxDonationType";
            this.textBoxDonationType.Size = new System.Drawing.Size(215, 22);
            this.textBoxDonationType.TabIndex = 4;
            // 
            // textBoxDonationAmount
            // 
            this.textBoxDonationAmount.Location = new System.Drawing.Point(426, 286);
            this.textBoxDonationAmount.Name = "textBoxDonationAmount";
            this.textBoxDonationAmount.Size = new System.Drawing.Size(215, 22);
            this.textBoxDonationAmount.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(359, 238);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Type";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(359, 260);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Amount";
            // 
            // textBoxDate
            // 
            this.textBoxDate.Location = new System.Drawing.Point(426, 314);
            this.textBoxDate.Name = "textBoxDate";
            this.textBoxDate.Size = new System.Drawing.Size(215, 22);
            this.textBoxDate.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(359, 314);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 16);
            this.label3.TabIndex = 9;
            this.label3.Text = "Date";
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.Location = new System.Drawing.Point(684, 210);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(75, 23);
            this.buttonUpdate.TabIndex = 10;
            this.buttonUpdate.Text = "Update";
            this.buttonUpdate.UseVisualStyleBackColor = true;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(684, 260);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonAdd.TabIndex = 11;
            this.buttonAdd.Text = "Add";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // buttonDelete
            // 
            this.buttonDelete.Location = new System.Drawing.Point(684, 314);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(75, 23);
            this.buttonDelete.TabIndex = 12;
            this.buttonDelete.Text = "Delete";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // textBoxPersonID
            // 
            this.textBoxPersonID.Location = new System.Drawing.Point(426, 197);
            this.textBoxPersonID.Name = "textBoxPersonID";
            this.textBoxPersonID.Size = new System.Drawing.Size(215, 22);
            this.textBoxPersonID.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(362, 197);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 16);
            this.label4.TabIndex = 14;
            this.label4.Text = "PersonID";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxPersonID);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.buttonUpdate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxDate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxDonationAmount);
            this.Controls.Add(this.textBoxDonationType);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridViewPerson);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dB2DataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.animalBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB2DataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB2DataSet3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.animalBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPerson)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.donationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.donationBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DB2DataSet2 dB2DataSet2;
        private System.Windows.Forms.BindingSource animalBindingSource;
        private DB2DataSet2TableAdapters.AnimalTableAdapter animalTableAdapter;
        private System.Windows.Forms.BindingSource animalBindingSource1;
        private DB2DataSet3 dB2DataSet3;
        private System.Windows.Forms.BindingSource dB2DataSet3BindingSource;
        private System.Windows.Forms.DataGridView dataGridViewPerson;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private DB2DataSet2TableAdapters.EmployeeTableAdapter employeeTableAdapter;
        private System.Windows.Forms.BindingSource personBindingSource;
        private DB2DataSet2TableAdapters.PersonTableAdapter personTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn personIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn personFirstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn personLastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn personAgeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn personCountryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn personPhoneNrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn personEmailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeSpecializationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeSalaryDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource employeeBindingSource1;
        private System.Windows.Forms.BindingSource donationBindingSource;
        private DB2DataSet2TableAdapters.DonationTableAdapter donationTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn personIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn donationTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn donationAmountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn donationDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource donationBindingSource1;
        private System.Windows.Forms.TextBox textBoxDonationType;
        private System.Windows.Forms.TextBox textBoxDonationAmount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.TextBox textBoxPersonID;
        private System.Windows.Forms.Label label4;
    }
}

